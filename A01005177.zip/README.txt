Dear marker,

The assignment functionality contains of the following:

- user can start/pause the game
- user can control the speed of the game with a slider
- user is able to save/load game as long as the save/load file have .out extention
- when paused, user is able to trace back (and forth) executed steps

Please, feel free to contact me for any clarifications: 
eugene.my88@gmail.com