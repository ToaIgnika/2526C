package ca.bcit.comp2526.a2b;

import java.awt.GridLayout;
import javax.swing.JPanel;

/**
 * GameFrame.
 * 
 *
 * "I made this code longer than usual because I lack time to make it short"
 * 
 * @author Yevhen
 * @version Oct 19, 2017
 *
 */
public class GameFrame extends JPanel {

    /**
     * UID version.
     */
    private static final long serialVersionUID = 1L;
    private final World world;

    /**
     * Constructor for gameframe object.
     * 
     * @param w
     *            of type World.
     */
    public GameFrame(final World w) {
        world = w;
    }

    /**
     * initialize the layout.
     */
    public void init() {
        setLayout(new GridLayout(world.getRowCount(), world.getColCount()));

        for (int row = 0; row < world.getRowCount(); row++) {
            for (int col = 0; col < world.getColCount(); col++) {
                add(world.getCellAt(row, col));
            }
        }
        addMouseListener(new TurnListener(this));
    }

    /**
     * Update the world frame.
     */
    public void worldUpdate() {
        world.reinit();
        init();
    }

    /**
     * Take turn.
     */
    public void takeTurn() {
        world.takeTurn();
        repaint();
    }
}
