package ca.bcit.comp2526.a2b;

/**
 * Element.java.
 * 
 *
 * "I made this code longer than usual 
 * because I lack time to make it short"
 * @author Yevhen
 * @version Nov 19, 2017
 *
 */
public abstract class Element {
    
    /**
     * Constructor for Element.
     */
    public Element() {
        
    }
    
    /**
     * init method.
     */
    void init() {
        
    };
    
    /**
     * setCell method.
     */
    void setCell() {
        
    }
    
    /**
     * get moved method.
     * @return true if moved.
     */
    boolean getMoved() {
        return false;
    }

    /**
     * move method.
     */
    void move() {
        
    }
    
    /**
     * life decreaser.
     */
    void decLife() {
    }
    
    /**
     * setter for moved.
     * @param isMoved of type boolean.
     */
    void setMoved(boolean isMoved) {
        
    }
    
    /**
     * getter for lifecount.
     * @return lifecount.
     */
    int getLife() {
        return 0;
        }
    
    /**
     * reproduction method.
     */
    void getBorn() {
    
    }
    
    /**
     * getter for type.
     * @return ETYPE.
     */
    ETYPE getType() {
        return null;
    };
}
