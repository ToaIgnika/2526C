package ca.bcit.comp2526.a2b;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

/**
 * ControlPanel.java.
 * 
 *
 * "I made this code longer than usual 
 * because I lack time to make it short"
 * @author Yevhen
 * @version Nov 19, 2017
 *
 */
public class ControlPanel extends JPanel {

    /**
     * min fps.
     */
    private static final int FPS_MIN = 0;
    /**
     * max fps.
     */
    private static final int FPS_MAX = 20;
    /**
     * initial fps.
     */
    private static final int FPS_INIT = 1; // initial frames per second
    /**
     * serial uid.
     */
    private static final long serialVersionUID = 1L;
    private final TimerFrame timer;
    private final GameFrame frame;

    /**
     * Constructor for control panel.
     * @param t of type TimerFrame.
     * @param g of type GameFrame.
     */
    public ControlPanel(TimerFrame t, GameFrame g) {
        timer = t;
        frame = g;
        JSlider framesPerSecond = new JSlider(JSlider.HORIZONTAL, FPS_MIN,
                FPS_MAX, FPS_INIT);
        framesPerSecond.addChangeListener(new SlideListener());
        // Turn on labels at major tick marks.
        framesPerSecond.setMajorTickSpacing(Integer.valueOf("5"));
        framesPerSecond.setMinorTickSpacing(1);
        framesPerSecond.setPaintTicks(true);
        framesPerSecond.setPaintLabels(true);

        JButton bstart = new JButton("Start");
        bstart.addActionListener(new StartEvent());
        JButton bpause = new JButton("Pause");
        bpause.addActionListener(new PauseEvent());
        JButton brefresh = new JButton("Refresh");
        brefresh.addActionListener(new RefreshEvent());
        JLabel bseed = new JLabel("<FPS>");

        add(bstart);
        add(bpause);
        add(brefresh);
        add(bseed);
        add(framesPerSecond);
    }

    /**
     * SlideListener class.
     * 
     *
     * "I made this code longer than usual 
     * because I lack time to make it short"
     * @author Yevhen
     * @version Nov 19, 2017
     *
     */
    class SlideListener implements ChangeListener {
        /**
         * statechange listener.
         * @param e ChangeEvent e.
         */
        public void stateChanged(ChangeEvent e) {
            JSlider source = (JSlider) e.getSource();
            if (!source.getValueIsAdjusting()) {
                int fps = (int) source.getValue();

                if (fps == 0) {
                    timer.pauseTimer();
                } else {
                    timer.setTimer(Integer.valueOf("1000") / fps);
                    if (!timer.runStatus()) {
                        timer.startTimer();
                    }
                }
            }
        }
    }

    /**
     * PauseEvent class.
     * 
     *
     * "I made this code longer than usual 
     * because I lack time to make it short"
     * @author Yevhen
     * @version Nov 19, 2017
     *
     */
    class PauseEvent implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // TODO Auto-generated method stub
            timer.pauseTimer();
        }
    }

    /**
     * StartEvent class.
     * 
     *
     * "I made this code longer than usual 
     * because I lack time to make it short"
     * @author Yevhen
     * @version Nov 19, 2017
     *
     */
    class StartEvent implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // TODO Auto-generated method stub
            timer.startTimer();
        }
    }

    /**
     * RefreshEvent class.
     * 
     *
     * "I made this code longer than usual 
     * because I lack time to make it short"
     * @author Yevhen
     * @version Nov 19, 2017
     *
     */
    class RefreshEvent implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            // TODO Auto-generated method stub
            timer.pauseTimer();
            frame.worldUpdate();
        }
    }
}
